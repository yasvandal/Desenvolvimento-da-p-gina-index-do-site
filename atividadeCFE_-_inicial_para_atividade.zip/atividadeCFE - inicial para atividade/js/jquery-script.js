function cadastro() {
    alert("Cadastrado com sucesso!");
    window.location.href = "index.html";
    }